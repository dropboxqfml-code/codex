@echo off
setlocal
"%~dp0ATIVBatteryGuard.ValidationCheck.exe"
echo.
pause
