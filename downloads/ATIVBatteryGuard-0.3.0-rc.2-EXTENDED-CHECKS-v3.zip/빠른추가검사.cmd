@echo off
setlocal
"%~dp0ATIVBatteryGuard.ExtendedCheck.exe" --quick
set "ativ_extended_exit=%ERRORLEVEL%"
echo.
pause
exit /b %ativ_extended_exit%
