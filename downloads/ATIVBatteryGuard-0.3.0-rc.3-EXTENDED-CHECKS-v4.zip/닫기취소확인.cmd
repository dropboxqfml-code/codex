@echo off
setlocal
"%~dp0ATIVBatteryGuard.ExtendedCheck.exe" --ime-close
set "ativ_extended_exit=%ERRORLEVEL%"
echo.
pause
exit /b %ativ_extended_exit%
