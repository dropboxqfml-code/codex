# 하드웨어 조사

## 확인된 사실

최신 파일 식별 TXT에서 **Sabi3 3.2.0.0의 x64·x86과 공개 예제 함수 이름 5개**를 실제 확인했습니다. Settings 하위 폴더에서 네 대상 파일이 모두 관측됐으며 wsabi는 여러 다른 해시가 있습니다. [파일별 관측과 적용 한계](SABI3_COMPATIBILITY_REVIEW.md)에 기록했습니다. 메타데이터 확인을 현재 DLL 초기화·OEM 조회 성공으로 보지 않습니다.

사용자 화면·진단과 로컬 정적 분석에서 확인한 범위입니다. 원본 사용자 진단 파일과 삼성 바이너리는 저장소·배포물에 포함하지 않습니다.

- 모델: `940X3G/930X3G`, BIOS: `P05ACJ.128.140819.dg`.
- Windows 10 Home `10.0.19045`, OS와 앱 프로세스는 x64.
- 이전에 Windows와 앱이 모두 표시한 0%는 사용자가 당시의 실제 상태임을 확인했습니다. 수치 보정 대상이 아닙니다.
- 2026-10-31 후속 화면과 진단에서는 **62%, AC 연결 안 됨, 방전 중**이었습니다. `GetSystemPowerStatus`와 `Win32_Battery` 잔량이 62%로 일치했습니다. 현재 값은 계속 Windows 측정에 따라 갱신합니다.
- 2026-11-01 진단에서는 GetSystemPowerStatus 53%, WMI 52%, AC 연결 안 됨이었습니다. 순차 조회의 1%p 차이이며 값을 보정하지 않습니다.
- 같은 진단의 표준 배터리 조회는 인터페이스 1개에서 완료됐고 Capabilities는 `0x80000000`이었습니다. 시스템 배터리 표시만 있고 표준 충전·방전 요청 지원 비트는 없습니다. 현재 드라이버의 이 표준 경로를 제어에 사용하지 않습니다. OEM 기능 전체의 부재로 확정하지는 않습니다.
- 후속 `diagnostics-20261101T021357`에서는 52%, AC 연결, 충전 중이며 Win32와 WMI 잔량이 일치했습니다. 새 결과 해석 문장이 TXT에 정상 기록됐고 표준 지원 비트는 같았습니다. 이 TXT로 새 메인 화면의 렌더링까지 검증했다고 주장하지 않습니다.
- 공개 구형 Windows 래퍼와 Linux SABI3에서 배터리 수명 연장의 조회·변경 명령 후보를 찾았습니다. Windows 래퍼는 삼성 DLL에 의존하며 현재 WMI 바이트 계약이나 해당 모델의 실제 제어를 검증하지 않습니다. [공개 규약 비교](PUBLIC_CONTROL_PROTOCOL_REVIEW.md)에 출처와 한계를 기록했습니다.
- Samsung Settings 2.2.0이 설치되어 있지만 충전 제한 메뉴가 없다고 사용자가 확인했습니다.
- 사용자는 `Sabi3.dll`이 설치 폴더에 있다고 추가 보고했고 참고 경로 `C:\Program Files (x86)\Samsung\Setting`을 전달했습니다. 클라우드에서 이 폴더나 실제 DLL을 확인한 결과는 아닙니다. 이번에는 [DLL 후보 목록](SAMSUNG_DLL_CANDIDATES.md)으로 기록했으며 앱의 탐색·실행 경로로 사용하지 않습니다.
- 사용자는 BIOS 설정에도 배터리 충전 제한·수명 연장 메뉴가 없음을 추가 확인했습니다. 두 설정 화면의 부재는 관측 사실이며, 미공개 펌웨어 기능의 유무나 제어 안전성을 입증하지 않습니다. 메뉴 재점검은 요청하지 않습니다.
- `SamsungSystemConfiguration` 서비스가 실행 중인 것으로 보고됐습니다. 서비스 실행은 충전 제한 지원 증거가 아닙니다.
- 업로드된 `SamsungConfigurationMonitor.exe`는 같은 폴더의 `wsabi.dll`을 정적으로 참조합니다. 확인된 호출 문맥은 팬·정숙 모드입니다. 이 문맥의 `0x80`을 배터리 80% 명령으로 해석하지 않습니다.
- `wsabi.dll` 수집에 성공했습니다. 파일은 22,920바이트이며 SHA-256은 `564b640d62db2a4e4b56c6331e0e526bad2ac1fcf438a41a9e5241551f457b6e`입니다.
- 해당 DLL은 x86 네이티브 WMI/COM SABI 중계 DLL입니다. export는 `InitBIOSInterface`, `UninitBIOSInterface`, `CallBIOSInterface`, `GetBiosVersion`, `GetBiosMode`입니다.
- 정적 코드에서 `ROOT\WMI`, `WmiAcpiVersion`, `WmiAcpiMethod`, `DataBuffer`, `Bytes`, `inData`, `outData`, `CallSabiFunction` 참조를 확인했습니다.
- 후속 실제 노트북 진단에서 아래 클래스·메서드 정의를 모두 찾았고, 보고서에 기록된 조회 오류는 없었습니다. 속성 이름·형식과 메서드 정의만 읽었습니다. 해당 인스턴스 값은 읽지 않았고 OEM 메서드는 실행하지 않았습니다.

| 정의 | 실제 확인한 스키마 |
| --- | --- |
| `WmiAcpiVersion` | `Active: Boolean`, `InstanceName: String`, `version: UInt32` |
| `WmiAcpiMethod` | `Active: Boolean`, `InstanceName: String`; `CallSabiFunction(inData: Object) → outData: Object` |
| `DataBuffer` | `Bytes: UInt8[]` |

`CallBIOSInterface`에는 실제 WMI 메서드 실행 경로가 있으므로 읽기 전용 진단 함수로 취급할 수 없습니다. `GetBiosMode`가 조회하는 것은 SMBIOS 정보이며 배터리 보호 모드로 볼 근거가 없습니다. 이 분석에서는 OEM 파일을 실행·로드하거나 DLL 함수를 호출하지 않았습니다. 삼성 DLL의 전자서명 신뢰 검증도 수행하지 않았습니다.

## 가정

기존 Samsung/SABI 이름 필터만 사용한 목록은 위 클래스를 찾지 못했지만, 정확한 클래스 이름을 사용한 후속 정의 조회에서는 발견했습니다. 이로써 중계 인터페이스의 존재를 확인했으며 충전 제어 지원을 확인한 것은 아닙니다.

Samsung Settings 앱의 EXE·DLL에서 메뉴·모델 지원 조건을 확인하려던 접근은 이전 단계의 가설입니다. 현재는 사용자 조건에 따라 해당 앱에서 DLL을 추출할 수 없다고 가정하고 진행합니다. 추가 삼성 파일 수집이나 분석을 선행 조건으로 요구하지 않습니다. 공개 자료에서 해당 모델의 Windows OEM 명령과 실제 설정 조회 규약을 확인하는 경로로 전환했습니다. [공개 자료 검토 결과](DLL_INDEPENDENT_RESEARCH.md)를 참고하세요.

## 아직 검증되지 않은 항목

- `CallSabiFunction` 입력 바이트의 의미와 모델·BIOS별 지원·안전 범위
- 공개 명령 후보를 현재 모델의 Windows WMI로 전달하는 방법, 실제 80%/100% 상한의 의미와 현재 설정을 읽는 방법
- Samsung Settings 앱의 충전 메뉴 노출·모델 지원 조건
- Windows에서 쓸 수 있는 공식·검증된 OEM 제어 인터페이스
- 앱 종료·재부팅·전원 차단 뒤 펌웨어 설정 유지 여부
- 삼성 DLL의 공식 ABI와 전자서명 신뢰

클래스나 메서드가 발견되어도 실제 제어 지원으로 표시하지 않습니다. 하드웨어 상태는 계속 미지원으로 유지합니다.

## 다음 검증

현재는 삼성 프로그램 파일의 추가 수집·분석을 보류합니다. 먼저 해당 버전의 사용권 계약과 정확한 모델·BIOS·Windows 조합의 공식 지원 근거를 확인합니다. 공식 사이트 조회 준비 상태와 미전송 문의 초안은 [OFFICIAL_SUPPORT_REVIEW.md](OFFICIAL_SUPPORT_REVIEW.md)에 기록했습니다. 아직 공식 문서나 계약 조항을 열람하지 못했으므로 허용·금지나 충전 기능 지원 여부를 확정하지 않습니다.

실제 커널·펌웨어 제어 코드는 별도의 명시적 사용자 승인과 모델 적합성·안전성 근거가 확보된 뒤에만 추가할 수 있습니다.

## 설치 위치 정보 누락 결과와 수정

후속 사용자 Settings 분석 ZIP은 모듈 0개인 보고서 전용 자료였습니다. 32비트 Samsung Settings 등록은 발견됐지만 InstallLocation/DisplayIcon 문자열이 모두 비어 ICON_PATH_NOT_PROVIDED로 종료했습니다. 이는 앱 미설치나 배터리 제어 미지원의 증거가 아닙니다.

이 경우에만 시스템 Program Files/PFx86/ProgramData의 Samsung\Settings 또는 Samsung\Samsung Settings 전용 후보 최대 6곳을 확인하도록 수정했습니다. 등록 불일치나 제공 경로 거부에는 적용하지 않습니다. 링크 차단·회사 정보/PE 검사·복사 한도·동의 확인은 유지합니다. 수정 후 실제 Windows 파일 확보는 아직 검증하지 않았습니다.

## 2026-11-01 사용자 결과 확인

위치 누락 수정판의 후속 보고서에서 `RegisteredKnownDirectory`, `SettingsProgramFilesX86`, `Settings.exe` 앵커 발견을 확인했습니다. 대체 위치 확인은 동작했지만 회사 표시 정보가 수집 조건을 통과하지 않아 `COMPANY_NOT_SAMSUNG`으로 제외됐으며 복사 모듈 수는 0개입니다. 회사 정보가 누락된 것인지 다른 값인지는 이 보고서로 구분할 수 없습니다. 실제 파일 바이트는 아직 확보하지 못했습니다.

같이 재첨부된 이전 서비스 ZIP의 5개 모듈 SHA-256은 기존 분석 대상과 모두 일치했습니다. `wsabi.dll`도 같은 파일이며 배터리 명령에 관한 추가 근거는 없습니다. 원본 사용자 ZIP이나 OEM 파일은 저장소에 포함하지 않습니다.

앞서 요청했던 Settings.exe 직접 전달은 사용권 확인 전까지 철회했습니다. 추가 OEM 파일을 요청하거나 분석하지 않습니다. 위 수집 결과는 과거 조사 기록이며, 현재 진행 방향은 공식 지원·사용권 확인입니다. 실제 충전 제어는 계속 미지원입니다.

## Windows 버전별 지원 차이에 관한 사용자 제공 단서

사용자는 Windows 8에서는 충전 제한을 지원했으나 Windows 10 및 Samsung Settings 2.2 이후 메뉴가 사라졌다는 보고를 제시했습니다. 현재 사용 환경은 Windows 10과 Settings 2.2.xx입니다. 해당 보고의 원문 URL·정확한 모델·BIOS·이전 소프트웨어 버전은 아직 확보하지 못해 과거 지원 사실을 독립 검증한 것은 아닙니다.

같은 모델의 과거 공식 지원이 확인된다면 Windows 10용 OEM 프로그램의 기능 변경, 모델 판별, 드라이버/API 호환성 또는 지원 정책 차이를 우선 조사합니다. 보고만으로 정확한 원인이나 현재 펌웨어의 제어 가능성을 확정하지 않습니다. 메뉴 부재를 하드웨어 불가능으로 단정하지 않으며, UI 제거만을 확정 원인으로 취급하지도 않습니다.

다음 문서 비교는 Windows 8 당시 같은 모델의 공식 충전 제한 설명·프로그램 버전·요구 드라이버와 Windows 10/Settings 2.2의 공식 지원 범위입니다. 사용자에게 요청할 자료는 보고의 공개 URL 또는 문서 제목이며 삼성 실행 파일·DLL의 추가 수집은 계속 보류합니다. 실제 충전 제어는 미지원 상태를 유지합니다.
