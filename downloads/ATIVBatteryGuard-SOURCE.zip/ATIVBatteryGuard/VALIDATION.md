# Settings 앱 분석판 검증 기록

## 현재 Windows 배터리 조회판

삼성 DLL 추출 없이 표준 Windows 배터리 드라이버의 요청 지원 여부를 읽는 진단을 추가했습니다. **진단 파일 만들기**로 생성되는 TXT의 ‘Windows 표준 배터리 드라이버의 요청 지원 여부’ 섹션에서 볼 수 있습니다. BatteryCharge/BatteryDischarge 지원 비트는 80% 충전 상한 지원의 증거가 아니며, 결과가 있어도 실제 제어는 미지원으로 유지합니다.

GENERIC_READ, QUERY_TAG(대기 0), QUERY_INFORMATION(정보 수준 0)만 사용합니다. 자체 보조 프로세스의 10초 제한과 최대 8개 인터페이스·16 KiB 결과 한도를 적용합니다. 장치 경로·태그·시리얼번호·고유 ID를 보고하지 않습니다. SET 요청이나 OEM 메서드는 실행하지 않습니다. 앱 시작이나 주기적 표시에서는 보조 조회를 실행하지 않습니다.

이번 회귀 테스트는 130개 통과·실패 0개·건너뜀 0개입니다. 새 기능의 실제 Windows 실행은 아직 미검증입니다. [구조·출처·검증 한계](WINDOWS_BATTERY_QUERY.md)에 상세히 기록했습니다. 아래 버전별 설명은 이전 단계의 이력입니다.


## 삼성 파일 추출 제외판의 현재 조건

사용자의 Samsung Settings에서 DLL을 추출할 수 없다는 조건으로 진행합니다. WPF 배포 프로젝트에서 삼성 파일 수집기와 위치 탐색기를 컴파일 제외했고 수집 확인 창과 UI도 제거했습니다. 장치 조회·로컬 설정·시뮬레이션·공식 문의문 복사는 유지합니다. 추출한 삼성 DLL은 필요하지 않습니다. 자체 Core DLL과 Windows 내장 프레임워크는 앱 구성 요소입니다.

Microsoft 공식 문서에서 일반 배터리 설정 요청 경로는 확인했지만, 검토한 인터페이스에는 지속되는 80% 충전 상한 항목이 없습니다. OEM WMI 입력 규약은 아직 확보하지 못했으며 실제 제어는 미지원입니다. [DLL 추출 없는 개발 경로와 실제 확인한 출처](DLL_INDEPENDENT_RESEARCH.md)를 참고하세요.

아래 수집 관련 설명은 이전 단계의 기록이며 현재 배포 기능이 아닙니다.


## 공식 지원 검토판의 현재 상태

새 제품 시작 구성은 OEM 파일 수집기와 확인 콜백을 전달하지 않습니다. 수집 명령은 비활성화되고 직접 비동기 호출도 작업 없이 반환합니다. 기존 수집 코드는 소스 이력과 회귀 검증을 위해 보관하며 현재 제품 경로에서 사용하지 않습니다.

문의문 복사는 장치 정보 조회 완료 후에만 사용할 수 있고, 조회 갱신 중의 오래된 값과 종료 후 복사를 차단합니다. 공개 장치 정보 필드만 사용하며 상세 오류와 경로를 문의문에서 제외합니다. 클립보드에 복사할 뿐 실제 문의 제출·네트워크 통신은 수행하지 않습니다.

이 변경을 포함한 전체 portable suite는 **114개 통과·실패 0개·건너뜀 0개**, 실제 WPF 빌드는 경고·오류 0개입니다. Windows에서 새 문의 복사 동작은 아직 미검증입니다. 아래 표와 수집 절차는 이전 단계의 기록입니다.


2026-10-31 한국 시간 기준입니다. 이전 WMI 진단판의 확인 결과와 이번 Settings 수집 변경을 구분합니다.

## 이전 WMI 정의 진단판

| 항목 | 실제 확인 결과 |
| --- | --- |
| .NET Framework 4.8 x64 WPF 빌드 | 성공, 경고 0개·오류 0개 |
| 공유 Core·ViewModel 및 WMI 정책 회귀 테스트 | 78개 통과·실패 0개·건너뜀 0개 |
| 실행 파일 정적 검사 | x64 GUI, .NET 4.8 참조, 관리 진입점 확인 |
| 실제 XAML 컴파일 산출물 | `app.baml`, `views/mainwindow.baml` 포함 확인 |
| 일반 권한 manifest | `asInvoker` 포함 확인 |
| Windows 노트북 앱 실행 | 사용자 화면으로 창·배터리 표시 확인 |
| 실제 WMI 클래스 정의 | 사용자 TXT에서 정확한 클래스 3개·메서드 서명 확인, 조회 오류 없음 |

사용자 최신 관측은 배터리 62%, AC 연결 안 됨, 방전 중이며 Win32와 WMI 잔량이 일치했습니다. 이전 0%는 과거 관측이며 현재 고정값이 아닙니다. 클래스 정의 조회는 메서드를 실행하거나 충전 제한을 적용한 시험이 아닙니다.

## 새 Settings 앱 파일 수집

| 항목 | 현재 상태 |
| --- | --- |
| 새 변경의 WPF 빌드 | 성공, 경고 0개·오류 0개 |
| 새 변경의 portable 회귀 테스트 | 108개 통과·실패 0개·건너뜀 0개 |
| 새 수집 기능의 Windows 동작 | 미검증, 새 ZIP 결과 필요 |
| Windows GUI 자동 self-test | 미실행 |
| 실제 충전 제한 | 구현하지 않음, 항상 미지원 |

새 suite는 기존 78개와 Settings 경계 검사 30개를 이번 변경에서 다시 실행했습니다. pure 정책과 공유 Core·ViewModel의 회귀 검증이며, Windows Registry 열거·파일 수집을 실행한 결과가 아닙니다.

재실행할 주요 명령입니다. `dotnet`은 .NET 8 SDK를 사용합니다.

```sh
dotnet restore ATIVBatteryGuard.sln
dotnet build ATIVBatteryGuard.sln -c Release --no-restore -p:UseSharedCompilation=false -m:1
dotnet run --project tests/ATIVBatteryGuard.PortableTests.csproj -c Release --no-restore -p:UseSharedCompilation=false -- --report reports/portable-tests.json
python scripts/package_preview.py --test-report reports/portable-tests.json
```

Windows용 `scripts/Test-Windows.ps1`은 제공하지만 이 환경에서는 실행하지 않았습니다. 빌드 성공·클래스 발견·파일 수집 성공을 실제 충전 제어 성공으로 해석하지 않습니다. 과거 149개 또는 이전 WMI 판의 78개 시험 기록을 새 변경의 시험 수치로 재사용하지 않았습니다.

## 위치 누락 수정판

사용자 ZIP에서 앱 등록만 있고 설치·아이콘 위치가 없는 원인을 확인했습니다. 수정 후 전체 portable suite는 108개이며 등록 불일치/제공 경로의 대체 조회 금지와 고정 후보 범위를 검사합니다. 새 native 대체 조회는 Windows 결과가 필요합니다.
