"""One background discovery worker controlled by a local status interface.

The application holds the separate monitor-purpose lease for its whole life.
Every scan still takes the existing shared scan lease in run_watch_trial. No
SQLite connection or Playwright object crosses into the HTTP/UI thread.
"""

import math
import re
import shutil
import threading
from datetime import UTC, datetime, timedelta
from pathlib import Path

from image_monitor.artifact_files import _plain_path
from image_monitor.candidate_runtime import run_candidate_trial
from image_monitor.monitor_diagnosis import PROFILE_GAP, read_latest_list_diagnosis
from image_monitor.monitor_settings import (
    load_monitor_settings,
    save_monitor_settings,
    validate_interval,
)
from image_monitor.queue import QueueError, QueueStore
from image_monitor.watch_detail_source import monitor_detail_scan_id
from image_monitor.watch_diagnosis import public_list_diagnosis
from image_monitor.watch_planner import next_poll_at
from image_monitor.watch_runtime import (
    PARTIAL_COVERAGE_GAPS,
    _control,
    _eligibility,
    _stamp,
    _stored_time,
    matches_partial_coverage_scan,
    run_watch_trial,
)
from image_monitor.watch_store import MONITOR_SCOPE, WatchStore

MIN_FREE_BYTES = 256 * 1024 * 1024
BUSY_BACKOFF_SECONDS = 15
MAX_DETAIL_BATCH = 2
_SCOPE_WHERE = "watch_name=? AND gallery_type=? AND gallery_id=? AND keyword=? AND search_type=?"
_TIME_STATUSES = {"unknown", "before_baseline", "at_or_after_baseline"}
_DETAIL_REASONS = {
    "header_unconfirmed",
    "observation_time_unavailable",
    "observation_before_baseline",
    "published_at_missing",
    "published_at_unparseable",
    "publication_time_inconsistent",
    "published_after_observation",
    "published_before_baseline",
    "published_at_or_after_baseline",
    "candidate_unavailable",
    "candidate_deleted",
    "detail_inspection_failed",
    "candidate_identity_or_baseline_invalid",
}
_DETAIL_STATUSES = {
    "candidate_test_completed",
    "candidate_test_partial",
    "candidate_test_failed",
    "candidate_test_cancelled",
    "candidate_waiting",
    "candidate_busy",
    "candidate_no_baseline",
    "candidate_no_pending",
}
_GAP_REASONS = {
    "excluded_rows_unverified",
    "order_unverified",
    "historical_cursor_unverified",
    "pagination_ambiguous",
    "max_pages",
    "pagination_missing",
    "overlap_incomplete",
    "empty_baseline_requires_end",
    "anchor_not_reached",
    "pagination_cycle",
    "pagination_unverified",
    "list_profile_unverified_or_incomplete",
    "list_transport_or_inspection_failure",
    "requested_stop",
}
_REPORT_STATUSES = {
    "watch_test_completed",
    "watch_waiting",
    "watch_busy",
    "watch_test_failed",
    "watch_test_partial",
    "watch_test_cancelled",
}
_SAVED_STATUSES = {"ready", "empty", "busy", "needs_review", "cancelled"}
_SAVED_REASONS = {
    "existing_saved_candidate_required",
    "another_scan_owns_this_scope",
    "native_save_in_progress",
    "pending_save_requires_review",
    "saved_catalog_requires_review",
    "requested_stop",
    "preview_limit",
}
_SAVED_MIMES = {
    "JPEG": "image/jpeg",
    "PNG": "image/png",
    "WEBP": "image/webp",
    "GIF": "image/gif",
    "BMP": "image/bmp",
}
_SAVED_EXTENSIONS = {
    "JPEG": "jpg",
    "PNG": "png",
    "WEBP": "webp",
    "GIF": "gif",
    "BMP": "bmp",
    "TIFF": "tiff",
}
_SAVED_FILE_FIELDS = (
    "saved_filename",
    "detected_format",
    "file_size",
    "width",
    "height",
    "frames",
    "preview_id",
    "preview_available",
    "group_id",
)
_MAX_PREVIEW_BYTES = 16 * 1024 * 1024
_MAX_TOTAL_PREVIEW_BYTES = 32 * 1024 * 1024
_OPERATION_COUNTS = (
    "candidate_uninspected",
    "save_ready",
    "save_planned",
    "save_active",
    "save_completed",
    "save_unavailable",
    "save_needs_review",
)


def _load_operations(*args, **kwargs):
    from image_monitor.monitor_operations import load_monitor_operations

    return load_monitor_operations(*args, **kwargs)


def _finish_completed(*args, **kwargs):
    from image_monitor.monitor_finish_action import run_completed_finish

    return run_completed_finish(*args, **kwargs)


def _save_one(*args, **kwargs):
    from image_monitor.monitor_save_action import run_dashboard_save

    return run_dashboard_save(*args, **kwargs)


def _load_saved_catalog(*args, **kwargs):
    # Import only when a configured local preview is requested. Opening the
    # discovery screen without a save root keeps the earlier startup behavior.
    from image_monitor.saved_catalog import load_saved_catalog

    return load_saved_catalog(*args, **kwargs)


def _safe_error_type(value):
    return (
        value
        if isinstance(value, str) and re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]{0,79}", value)
        else None
    )


class _Clock:
    def now(self):
        return datetime.now(UTC)


class MonitorController:
    """Start stopped, then alternate discovery with pending candidate inspections.

    This new watch scope leaves the earlier trial's baseline and candidates
    intact. Its first valid scan creates a new-only baseline. A verified two-page
    gap leaves coverage open while known candidates can still be inspected.

    Tests may inject clock.now() and clock.wait_for(event, seconds). The latter
    advances a controlled clock without real minute-long waits.
    """

    def __init__(
        self,
        work_root: Path,
        *,
        run_cycle=run_watch_trial,
        run_details=run_candidate_trial,
        clock=None,
        save_root=None,
        batch_root=None,
        catalog_loader=_load_saved_catalog,
        operations_loader=_load_operations,
        finish_runner=_finish_completed,
        save_runner=_save_one,
    ):
        if batch_root is not None and save_root is None:
            raise QueueError("Batch preview requires the legacy save root")
        self.work_root = _plain_path(Path(work_root).absolute()).resolve()
        if str(self.work_root).startswith("\\\\"):
            raise QueueError("A local monitor work root is required")
        self.work_root.mkdir(parents=True, exist_ok=True)
        self.database = _plain_path(self.work_root / "watch.sqlite")
        self._clock = clock or _Clock()
        _stamp(self._clock.now())
        self._run_cycle = run_cycle
        self._run_details = run_details
        self.save_root = Path(save_root) if save_root is not None else None
        self.batch_root = Path(batch_root) if batch_root is not None else None
        self._catalog_loader = catalog_loader
        self._operations_loader = operations_loader
        self._finish_runner = finish_runner
        self._save_runner = save_runner
        self._saved_images = {}
        settings = load_monitor_settings(self.work_root)
        self._lock = threading.RLock()
        self._wake = threading.Event()
        self._pause = threading.Event()
        self._stop = threading.Event()
        self._thread = None
        self._extra_due = None
        self._last_finished = None
        self._last_detail_finished = None
        self._latest_scan_id = None
        self._diagnosis_generation = None
        self._detail_scan_id = None
        self._resumable_scan_id = None
        self._seen_database = self.database.exists()
        self._state = {
            "scope_label": "만화 · ai · 제목+내용",
            "phase": "stopped",
            "task_kind": "list",
            "browser": "chrome",
            "interval_seconds": settings["interval_seconds"],
            "completed_cycles": 0,
            "partial_cycles": 0,
            "candidate_count": 0,
            "current_cycle_new": 0,
            "new_candidates": 0,
            "baseline_initialized": False,
            "last_scan_at": None,
            "next_eligible_at": None,
            "remaining_seconds": 0,
            "last_scan_status": None,
            "list_diagnosis": None,
            "gap_reason": None,
            "reason": None,
            "error_type": None,
            "browser_closed": True,
            "settings_editable": True,
            "detail_count": 0,
            "auto_details_checked": 0,
            "resume_detail_pending": False,
            "resumed_detail_slot": False,
            "detail_pending_count": 0,
            "detail_completed_count": 0,
            "detail_failed_count": 0,
            "details": [],
            "saved_status": "disabled" if self.save_root is None else "empty",
            "saved_reason": None,
            "saved_error_type": None,
            "saved_files_verified": 0,
            "saved_preview_count": 0,
            "saved_groups_verified": 0,
            "saved_files_omitted": 0,
            "saved_files": [],
            "operations_status": "disabled" if self.batch_root is None else "empty",
            "operations_reason": None,
            "operations_error_type": None,
            "operations_counts": dict.fromkeys(_OPERATION_COUNTS, 0),
            "operations_rows": [],
            "operations_rows_omitted": 0,
            "operations_wait_until": None,
            "operations_remaining_seconds": 0,
            "operations_can_finish": False,
            "operations_can_save": False,
            "operations_save_status": None,
            "operations_save_reason": None,
            "operations_save_error_type": None,
            "operations_save_tasks_started": 0,
            "operations_save_tasks_completed": 0,
            "operations_save_files_verified": 0,
            "operations_save_browser_closed": None,
            "operations_finish_status": None,
            "operations_finish_reason": None,
            "operations_finish_error_type": None,
            "operations_finish_files_verified": 0,
        }
        try:
            self._read_source(check_resume=True)
        except Exception as error:
            self._set(
                phase="needs_review",
                reason="stored_monitor_data_invalid",
                error_type=type(error).__name__,
            )

    def _set(self, **values):
        with self._lock:
            self._state.update(values)

    def status(self):
        with self._lock:
            result = self._state.copy()
            result["list_diagnosis"] = public_list_diagnosis(result["list_diagnosis"])
            result["details"] = [row.copy() for row in result["details"]]
            result["saved_files"] = [row.copy() for row in result["saved_files"]]
            result["operations_rows"] = [row.copy() for row in result["operations_rows"]]
            result["operations_counts"] = result["operations_counts"].copy()
            operation_due = result["operations_wait_until"]
            result["operations_remaining_seconds"] = (
                max(0, math.ceil((_stored_time(operation_due) - self._clock.now()).total_seconds()))
                if operation_due is not None
                else 0
            )
            result["settings_editable"] = result["phase"] == "stopped" and not self.is_alive()
            result["operations_can_save"] = (
                result["operations_can_save"]
                and result["settings_editable"]
                and result["browser_closed"] is True
                and result["operations_remaining_seconds"] == 0
            )
            due = result["next_eligible_at"]
            result["remaining_seconds"] = (
                max(0, math.ceil((_stored_time(due) - self._clock.now()).total_seconds()))
                if due is not None
                else 0
            )
            return result

    def is_alive(self):
        with self._lock:
            return self._thread is not None and self._thread.is_alive()

    def wait_stopped(self, timeout=None):
        with self._lock:
            thread = self._thread
        if thread is None:
            return True
        if thread is threading.current_thread():
            return False
        thread.join(timeout)
        return not thread.is_alive()

    def configure(self, interval_seconds):
        interval = validate_interval(interval_seconds)
        with self._lock:
            if self.is_alive() or self._state["phase"] != "stopped":
                raise QueueError("Stop the monitor before changing its interval")
            save_monitor_settings(self.work_root, interval)
            self._state["interval_seconds"] = interval
            return self.status()

    def start(self):
        with self._lock:
            if self._state["phase"] == "needs_review":
                raise QueueError("The monitor requires review before another start")
            if self.is_alive():
                if self._state["task_kind"] in {
                    "saved",
                    "operations",
                    "overview",
                    "finish",
                    "save",
                }:
                    return self.status()
                if self._pause.is_set() and not self._stop.is_set():
                    self._pause.clear()
                    self._wake.set()
                    self._state.update(phase="starting", reason=None)
                return self.status()
            self._stop.clear()
            self._pause.clear()
            self._wake.clear()
            self._state.update(
                phase="starting",
                task_kind="list",
                reason=None,
                error_type=None,
                operations_can_save=False,
                resumed_detail_slot=False,
            )
            self._thread = threading.Thread(
                target=self._work, name="image-monitor-discovery", daemon=True
            )
            self._thread.start()
            return self.status()

    def refresh_saved(self):
        """Refresh local completed files without doing I/O in the caller thread."""
        with self._lock:
            if (
                self.is_alive()
                or self._state["phase"] != "stopped"
                or self._state["browser_closed"] is not True
            ):
                raise QueueError("Stop the monitor before checking saved images")
            if self.save_root is None:
                return self.status()
            # Revoke all previous IDs before starting another bounded snapshot.
            self._saved_images = {}
            self._state.update(
                task_kind="saved",
                phase="verifying_saved",
                saved_status="checking",
                saved_reason=None,
                saved_error_type=None,
                saved_files_verified=0,
                saved_preview_count=0,
                saved_groups_verified=0,
                saved_files_omitted=0,
                saved_files=[],
            )
            self._stop.clear()
            self._pause.clear()
            self._wake.clear()
            self._thread = threading.Thread(
                target=self._work_saved, name="image-monitor-saved-files", daemon=True
            )
            self._thread.start()
            return self.status()

    def saved_image(self, image_id):
        """Return a cached immutable raster only; never reopen a local path."""
        if not isinstance(image_id, str) or not re.fullmatch(r"[0-9a-f]{32}", image_id):
            return None
        with self._lock:
            return self._saved_images.get(image_id)

    def refresh_operations(self):
        return self._begin_operations("operations")

    def refresh_overview(self):
        if self.batch_root is None:
            return self.refresh_saved()
        return self._begin_operations("overview")

    def finish_completed(self):
        """Request existing completed-file reconciliation; never retry a save."""
        return self._begin_operations("finish")

    def save_one(self):
        """Request one eligible post on the dedicated browser's main thread."""
        return self._begin_operations("save")

    def _begin_operations(self, kind):
        with self._lock:
            if self.is_alive() or self._state["phase"] not in {"stopped", "needs_review"}:
                raise QueueError("Stop the monitor before reviewing local work")
            if kind == "save" and not self.status()["operations_can_save"]:
                raise QueueError("Refresh the stopped monitor and choose an eligible save")
            if self.batch_root is None:
                if kind == "finish":
                    raise QueueError("Completed reconciliation requires configured batch roots")
                return self.status()
            if kind == "finish" and (
                self._state["operations_can_finish"] is not True
                or self._state["browser_closed"] is not True
            ):
                raise QueueError("Completed files must be reviewed before reconciliation")
            review = self._state["phase"] == "needs_review"
            self._state.update(
                task_kind=kind,
                phase={
                    "operations": "verifying_operations",
                    "overview": "verifying_overview",
                    "finish": "finishing_completed",
                    "save": "saving_candidate",
                }[kind],
                operations_status="checking",
                operations_reason=None,
                operations_error_type=None,
                operations_can_finish=False,
                operations_can_save=False,
                operations_counts=dict.fromkeys(_OPERATION_COUNTS, 0),
                operations_rows=[],
                operations_rows_omitted=0,
                operations_wait_until=None,
            )
            if kind in {"overview", "finish", "save"}:
                self._saved_images = {}
                self._state.update(
                    saved_status="checking",
                    saved_reason=None,
                    saved_error_type=None,
                    saved_files_verified=0,
                    saved_preview_count=0,
                    saved_groups_verified=0,
                    saved_files_omitted=0,
                    saved_files=[],
                )
            if kind == "finish":
                self._state.update(
                    operations_finish_status=None,
                    operations_finish_reason=None,
                    operations_finish_error_type=None,
                    operations_finish_files_verified=0,
                )
            elif kind == "save":
                self._state.update(
                    operations_save_status=None,
                    operations_save_reason=None,
                    operations_save_error_type=None,
                    operations_save_tasks_started=0,
                    operations_save_tasks_completed=0,
                    operations_save_files_verified=0,
                    operations_save_browser_closed=None,
                )
            self._stop.clear()
            self._pause.clear()
            self._wake.clear()
            self._thread = threading.Thread(
                target=self._work_operations,
                args=(kind, review),
                name="image-monitor-local-work",
                daemon=True,
            )
            self._thread.start()
            return self.status()

    @staticmethod
    def _operations_snapshot(snapshot):
        from image_monitor.monitor_operations import (
            OPERATIONS_REASONS,
            OPERATIONS_ROW_STATUSES,
            ROW_REASONS,
        )

        if not isinstance(snapshot, dict):
            raise QueueError("Local work did not return a snapshot")
        status, reason = snapshot.get("status"), snapshot.get("reason")
        counts = {key: snapshot.get(key) for key in _OPERATION_COUNTS}
        rows, omitted = snapshot.get("rows"), snapshot.get("rows_omitted", 0)
        can_finish, due = snapshot.get("can_finish"), snapshot.get("wait_until")
        if (
            status not in {"ready", "empty", "busy", "needs_review", "cancelled"}
            or reason is not None
            and reason not in OPERATIONS_REASONS
            or any(type(n) is not int or not 0 <= n <= 2**31 - 1 for n in counts.values())
            or not isinstance(rows, list)
            or len(rows) > 20
            or type(omitted) is not int
            or not 0 <= omitted <= 2**31 - 1
            or type(can_finish) is not bool
            or can_finish
            and (
                status not in {"ready", "needs_review"}
                or counts["save_active"] + counts["save_needs_review"] != 1
            )
            or due is not None
            and (not isinstance(due, str) or len(due) > 64)
        ):
            raise QueueError("Local work summary is invalid")
        if due is not None:
            due = _stamp(_stored_time(due))
        safe_rows, orders = [], set()
        for row in rows:
            if not isinstance(row, dict):
                raise QueueError("Local work row is invalid")
            order, image_count = row.get("order"), row.get("image_count")
            if (
                type(order) is not int
                or not 1 <= order <= 2**31 - 1
                or order in orders
                or row.get("status") not in OPERATIONS_ROW_STATUSES
                or row.get("reason") is not None
                and row.get("reason") not in ROW_REASONS
                or image_count is not None
                and (type(image_count) is not int or not 0 <= image_count <= 1000)
            ):
                raise QueueError("Local work row is invalid")
            orders.add(order)
            safe_rows.append(
                {key: row.get(key) for key in ("order", "status", "reason", "image_count")}
            )
        return {
            "operations_status": status,
            "operations_reason": reason,
            "operations_error_type": _safe_error_type(snapshot.get("error_type")),
            "operations_counts": counts,
            "operations_rows": safe_rows,
            "operations_rows_omitted": omitted,
            "operations_wait_until": due,
            "operations_can_finish": can_finish,
            "operations_can_save": (
                status == "ready"
                and snapshot.get("error_type") is None
                and reason in {"save_ready", "save_planned", "service_cooldown"}
                and (reason != "service_cooldown" or due is not None)
                and counts["save_ready"] + counts["save_planned"] > 0
                and counts["save_active"] == counts["save_needs_review"] == 0
                and not can_finish
            ),
        }

    def _operations_state(self):
        return self._operations_snapshot(
            self._operations_loader(
                self.work_root,
                self.save_root,
                self.batch_root,
                now=self._clock.now(),
                should_stop=self._requested_stop,
            )
        )

    def _catalog_state(self):
        options = {"should_stop": self._requested_stop}
        if self.batch_root is not None:
            options["batch_root"] = self.batch_root
        snapshot = self._catalog_loader(
            self.work_root,
            self.save_root,
            **options,
        )
        return self._saved_snapshot(snapshot)

    def _finish_state(self, report):
        from image_monitor.monitor_finish_action import (
            FINISH_ACTION_REASONS,
            FINISH_ACTION_STATUSES,
        )

        if (
            not isinstance(report, dict)
            or report.get("status") not in FINISH_ACTION_STATUSES
            or report.get("reason") not in FINISH_ACTION_REASONS
            or type(report.get("files_verified")) is not int
            or not 0 <= report["files_verified"] <= 2
        ):
            raise QueueError("Completed reconciliation returned an invalid report")
        return {
            "operations_finish_status": report["status"],
            "operations_finish_reason": report["reason"],
            "operations_finish_error_type": _safe_error_type(report.get("error_type")),
            "operations_finish_files_verified": report["files_verified"],
        }

    def _request_save(self, state):
        from image_monitor.monitor_save_action import validate_save_result

        due = state["operations_wait_until"]
        if not state["operations_can_save"] or (
            due is not None and _stored_time(due) > self._clock.now()
        ):
            self._set(
                operations_save_status="save_not_started",
                operations_save_reason="eligibility_changed",
                operations_save_browser_closed=True,
            )
            return state
        result = validate_save_result(
            self._save_runner(
                self.work_root, self.save_root, self.batch_root, should_stop=self._requested_stop
            )
        )
        self._set(
            operations_save_status=result["status"],
            operations_save_reason=result["reason"],
            operations_save_tasks_started=result["tasks_started"],
            operations_save_tasks_completed=result["tasks_completed"],
            operations_save_files_verified=result["files_verified"],
            operations_save_browser_closed=result["browser_closed"],
        )
        if (
            result["status"] == "monitor_batch_manual_review"
            or result["browser_closed"] is not True
        ):
            self._review("native_save_requires_review")
        return state if self._requested_stop() else self._operations_state()

    def _work_operations(self, kind, review):
        refresh_saved = kind in {"overview", "finish", "save"}
        try:
            state = self._operations_state()
            if kind == "finish" and not self._requested_stop():
                if state["operations_can_finish"] is not True:
                    raise QueueError("The completed reconciliation authorization changed")
                result = self._finish_state(
                    self._finish_runner(
                        self.work_root,
                        self.save_root,
                        self.batch_root,
                        should_stop=self._requested_stop,
                    )
                )
                # A late stop cannot erase an already completed reconciliation.
                self._set(**result)
                if not self._requested_stop():
                    state = self._operations_state()
            elif kind == "save" and not self._requested_stop():
                state = self._request_save(state)
            images = None
            if refresh_saved and not self._requested_stop():
                saved, images = self._catalog_state()
                state.update(saved)
            with self._lock:
                if self._requested_stop():
                    self._state.update(
                        operations_status="cancelled",
                        operations_reason="requested_stop",
                        operations_can_finish=False,
                        operations_can_save=False,
                    )
                    if refresh_saved:
                        self._state.update(saved_status="cancelled", saved_reason="requested_stop")
                else:
                    self._state.update(state)
                    if images is not None:
                        self._saved_images = images
        except BaseException as error:
            with self._lock:
                self._state.update(
                    operations_status="cancelled" if self._requested_stop() else "needs_review",
                    operations_reason="requested_stop"
                    if self._requested_stop()
                    else "operations_require_review",
                    operations_error_type=_safe_error_type(type(error).__name__),
                    operations_can_finish=False,
                    operations_can_save=False,
                )
                if refresh_saved:
                    self._saved_images = {}
                    self._state.update(
                        saved_status="cancelled" if self._requested_stop() else "needs_review",
                        saved_reason="requested_stop"
                        if self._requested_stop()
                        else "saved_catalog_requires_review",
                    )
                if kind == "finish" and self._state["operations_finish_status"] is None:
                    self._state.update(
                        operations_finish_status="batch_finish_cancelled"
                        if self._requested_stop()
                        else "batch_finish_manual_review",
                        operations_finish_reason="cancelled"
                        if self._requested_stop()
                        else "completed_batch_requires_review",
                        operations_finish_error_type=_safe_error_type(type(error).__name__),
                    )
                if kind == "save" and self._state["operations_save_status"] is None:
                    self._state.update(
                        operations_save_status="monitor_batch_manual_review",
                        operations_save_reason="save_action_failed",
                        operations_save_error_type=_safe_error_type(type(error).__name__),
                    )
                    self._review("native_save_requires_review")
        finally:
            with self._lock:
                if (
                    kind == "finish"
                    and self._state["operations_finish_status"] is None
                    and self._requested_stop()
                ):
                    self._state.update(
                        operations_finish_status="batch_finish_cancelled",
                        operations_finish_reason="cancelled",
                    )
                if (
                    kind == "save"
                    and self._state["operations_save_status"] is None
                    and self._requested_stop()
                ):
                    self._state.update(
                        operations_save_status="monitor_batch_cancelled",
                        operations_save_reason="requested_stop",
                        operations_save_browser_closed=True,
                    )
                self._state["phase"] = (
                    "needs_review"
                    if review or self._state["phase"] == "needs_review"
                    else "stopped"
                )

    @staticmethod
    def _saved_snapshot(snapshot):
        """Project and validate a bounded loader result before publishing it."""
        summary = getattr(snapshot, "summary", None)
        images = getattr(snapshot, "images", None)
        if not isinstance(summary, dict) or not isinstance(images, dict):
            raise QueueError("Saved catalog did not return a snapshot")
        status = summary.get("status")
        reason = summary.get("reason")
        if status not in _SAVED_STATUSES or reason is not None and reason not in _SAVED_REASONS:
            raise QueueError("Saved catalog status is invalid")
        files = summary.get("files")
        verified, preview_count = summary.get("files_verified"), summary.get("preview_count")
        groups = summary.get("groups_verified", 1 if files else 0)
        omitted = summary.get("files_omitted", 0)
        if (
            not isinstance(files, list)
            or not 0 <= len(files) <= 20
            or type(verified) is not int
            or not 0 <= verified <= 2000
            or type(omitted) is not int
            or omitted != verified - len(files)
            or type(groups) is not int
            or not 0 <= groups <= min(1000, verified)
            or verified > 2 * groups
            or type(preview_count) is not int
            or not 0 <= preview_count <= len(files)
            or len(images) != preview_count
            or status == "ready"
            and (not files or not groups)
            or status != "ready"
            and (files or images or verified or preview_count or groups or omitted)
        ):
            raise QueueError("Saved catalog counts are invalid")
        safe_files, expected_ids, names = [], set(), set()
        group_counts = {}
        total = 0
        for row in files:
            if not isinstance(row, dict):
                raise QueueError("Saved catalog file metadata is invalid")
            name, detected = row.get("saved_filename"), row.get("detected_format")
            available, image_id = row.get("preview_available"), row.get("preview_id")
            group_id = row.get("group_id")
            if (
                not isinstance(name, str)
                or not re.fullmatch(r"00[12]\.(?:jpg|png|webp|gif|bmp|tiff)", name)
                or group_id is not None
                and (not isinstance(group_id, str) or not re.fullmatch(r"[0-9a-f]{32}", group_id))
                or (group_id, name) in names
                or detected not in _SAVED_EXTENSIONS
                or not name.endswith("." + _SAVED_EXTENSIONS[detected])
                or type(available) is not bool
                or any(
                    type(row.get(key)) is not int or not 1 <= row[key] <= 2**31 - 1
                    for key in ("file_size", "width", "height", "frames")
                )
            ):
                raise QueueError("Saved catalog file metadata is invalid")
            names.add((group_id, name))
            group_counts[group_id] = group_counts.get(group_id, 0) + 1
            if available:
                if (
                    detected not in _SAVED_MIMES
                    or not isinstance(image_id, str)
                    or not re.fullmatch(r"[0-9a-f]{32}", image_id)
                    or image_id in expected_ids
                ):
                    raise QueueError("Saved catalog preview identity is invalid")
                expected_ids.add(image_id)
                value = images.get(image_id)
                if (
                    not isinstance(value, tuple)
                    or len(value) != 2
                    or value[0] != _SAVED_MIMES.get(detected)
                    or type(value[1]) is not bytes
                    or not 0 < len(value[1]) <= _MAX_PREVIEW_BYTES
                    or len(value[1]) != row["file_size"]
                ):
                    raise QueueError("Saved catalog preview data is invalid")
                total += len(value[1])
            elif image_id is not None:
                raise QueueError("Unavailable previews cannot retain an image identity")
            safe_files.append({key: row[key] for key in _SAVED_FILE_FIELDS if key in row})
        if (
            set(images) != expected_ids
            or total > _MAX_TOTAL_PREVIEW_BYTES
            or len(group_counts) > groups
            or any(count > 2 for count in group_counts.values())
            or None in group_counts
            and (len(group_counts) != 1 or groups != 1)
            or not omitted
            and len(group_counts) != groups
        ):
            raise QueueError("Saved catalog preview cache is invalid")
        return {
            "saved_status": status,
            "saved_reason": reason,
            "saved_error_type": _safe_error_type(summary.get("error_type")),
            "saved_files_verified": verified,
            "saved_preview_count": preview_count,
            "saved_groups_verified": groups,
            "saved_files_omitted": omitted,
            "saved_files": safe_files,
        }, images.copy()

    def _work_saved(self):
        try:
            options = {"should_stop": self._requested_stop}
            if self.batch_root is not None:
                options["batch_root"] = self.batch_root
            snapshot = self._catalog_loader(self.work_root, self.save_root, **options)
            state, images = self._saved_snapshot(snapshot)
            with self._lock:
                if self._requested_stop():
                    self._state.update(saved_status="cancelled", saved_reason="requested_stop")
                else:
                    self._saved_images = images
                    self._state.update(state)
        except BaseException as error:
            with self._lock:
                self._saved_images = {}
                self._state.update(
                    saved_status="cancelled" if self._requested_stop() else "needs_review",
                    saved_reason="requested_stop"
                    if self._requested_stop()
                    else "saved_catalog_requires_review",
                    saved_error_type=_safe_error_type(type(error).__name__),
                )
        finally:
            with self._lock:
                if self._state["phase"] != "needs_review":
                    self._state["phase"] = "stopped"

    def inspect_candidates(self):
        """Inspect an existing, bounded batch without starting list discovery."""
        with self._lock:
            if (
                self.is_alive()
                or self._state["phase"] != "stopped"
                or self._state["browser_closed"] is not True
            ):
                raise QueueError("Stop the monitor before inspecting existing candidates")
            self._state.update(task_kind="details", reason=None, error_type=None)
            if not self._state["baseline_initialized"]:
                self._state["reason"] = "existing_baseline_required"
                return self.status()
            if self._state["detail_pending_count"] == 0:
                self._state["reason"] = "no_unattempted_candidates"
                return self.status()
            self._stop.clear()
            self._pause.clear()
            self._wake.clear()
            self._state.update(phase="starting", operations_can_save=False)
            self._thread = threading.Thread(
                target=self._work,
                kwargs={"details_only": True},
                name="image-monitor-details",
                daemon=True,
            )
            self._thread.start()
            return self.status()

    def pause(self):
        with self._lock:
            if self.is_alive() and not self._stop.is_set():
                self._pause.set()
                self._wake.set()
                if self._state["phase"] != "needs_review":
                    self._state["phase"] = "pausing"
            return self.status()

    def stop(self):
        with self._lock:
            if self.is_alive():
                self._stop.set()
                self._wake.set()
                if self._state["phase"] != "needs_review":
                    self._state["phase"] = "stopping"
            elif self._state["browser_closed"] is True and self._state["phase"] != "needs_review":
                self._state["phase"] = "stopped"
            return self.status()

    def _requested_stop(self):
        return self._stop.is_set() or self._pause.is_set()

    def _wait(self, seconds):
        wait_for = getattr(self._clock, "wait_for", None)
        if wait_for is None:
            self._wake.wait(seconds)
        else:
            wait_for(self._wake, seconds)
        self._wake.clear()

    def _read_details(self, queue, candidate_count):
        """Read bounded, anonymous metadata; never retain a private DOM result."""
        if queue.schema_version < 5:
            return {
                "detail_count": 0,
                "detail_pending_count": candidate_count,
                "detail_completed_count": 0,
                "detail_failed_count": 0,
                "details": [],
            }
        totals = queue.connection.execute(
            "SELECT COUNT(*),COALESCE(SUM(status='completed'),0),"
            "COALESCE(SUM(status IN ('failed','started')),0) FROM candidate_details WHERE "
            + _SCOPE_WHERE,
            MONITOR_SCOPE.key(),
        ).fetchone()
        pending = queue.connection.execute(
            "SELECT COUNT(*) FROM watch_candidates c WHERE "
            "c.watch_name=? AND c.gallery_type=? AND c.gallery_id=? AND c.keyword=? "
            "AND c.search_type=? AND NOT EXISTS (SELECT 1 FROM candidate_details d WHERE "
            "d.watch_name=c.watch_name AND d.gallery_type=c.gallery_type AND "
            "d.gallery_id=c.gallery_id AND d.keyword=c.keyword AND "
            "d.search_type=c.search_type AND d.post_id=c.post_id)",
            MONITOR_SCOPE.key(),
        ).fetchone()[0]
        # JSON paths select only small scalar values, not the multi-megabyte snapshot.
        rows = queue.connection.execute(
            "SELECT status,json_extract(result_json,'$.classification.time_status'),"
            "json_extract(result_json,'$.classification.reason'),"
            "json_extract(result_json,'$.private_observation.snapshot.image_counts.included_unique'),"
            "json_extract(result_json,'$.private_observation.snapshot.image_counts.pending'),"
            "json_extract(result_json,'$.private_observation.http_status') "
            "FROM candidate_details WHERE "
            + _SCOPE_WHERE
            + " ORDER BY started_at DESC,attempt_id DESC LIMIT 10",
            MONITOR_SCOPE.key(),
        ).fetchall()
        details = []
        for index, row in enumerate(reversed(rows), start=max(1, totals[0] - len(rows) + 1)):
            status, time_status, reason, image_count, pending_images, http_status = row
            if status not in {"started", "completed", "failed"}:
                raise QueueError("Stored detail status is invalid")
            details.append(
                {
                    "order": index,
                    "status": status,
                    "time_status": time_status if time_status in _TIME_STATUSES else "unknown",
                    "reason": (
                        "candidate_deleted"
                        if http_status in {404, 410}
                        else reason
                        if reason in _DETAIL_REASONS
                        else None
                    ),
                    "image_count": (
                        image_count
                        if type(image_count) is int and 0 <= image_count <= 1000
                        else None
                    ),
                    "pending_images": (
                        pending_images
                        if type(pending_images) is int and 0 <= pending_images <= 1000
                        else None
                    ),
                }
            )
        finished = queue.connection.execute(
            "SELECT json_extract(result_json,'$.control.finished_at') FROM candidate_details WHERE "
            + _SCOPE_WHERE
            + " AND json_extract(result_json,'$.control.finished_at') IS NOT NULL "
            "ORDER BY julianday(json_extract(result_json,'$.control.finished_at')) DESC LIMIT 1",
            MONITOR_SCOPE.key(),
        ).fetchone()
        if finished is not None:
            self._last_detail_finished = _stored_time(finished[0])
        return {
            "detail_count": totals[0],
            "detail_pending_count": pending,
            "detail_completed_count": totals[1],
            "detail_failed_count": totals[2],
            "details": details,
        }

    def _read_source(self, *, partial_report=None, check_resume=False):
        now = self._clock.now()
        _stamp(now)
        if not self.database.exists():
            if self._seen_database:
                raise QueueError("The existing monitor database disappeared")
            return "ready", now
        _plain_path(self.database)
        self._seen_database = True
        with QueueStore(self.database, read_only=True) as queue:
            if queue.summary()["posts"] or queue.summary()["jobs"]:
                raise QueueError("The discovery monitor requires its separate watch database")
            state = WatchStore(queue).get_state(MONITOR_SCOPE)
            eligibility, due = _eligibility(queue, state, now)
            control = _control(state)
            finished = control.get("finished_at")
            if finished is not None:
                self._last_finished = _stored_time(finished)
                due = (
                    max(
                        due,
                        next_poll_at(
                            self._last_finished, interval_seconds=self._state["interval_seconds"]
                        ),
                    )
                    if due is not None
                    else None
                )
            count = 0
            if queue.schema_version >= 4:
                count = queue.connection.execute(
                    "SELECT COUNT(*) FROM watch_candidates WHERE watch_name=? AND gallery_type=? "
                    "AND gallery_id=? AND keyword=? AND search_type=?",
                    MONITOR_SCOPE.key(),
                ).fetchone()[0]
            latest = state["latest_scan"]
            self._latest_scan_id = latest["scan_id"] if latest else None
            if latest and self._diagnosis_generation != state["generation"]:
                if (
                    self._diagnosis_generation is None
                    or state["generation"] != self._diagnosis_generation + 1
                    or latest["gap_reason"] == PROFILE_GAP
                ):
                    self._set(
                        list_diagnosis=read_latest_list_diagnosis(
                            queue, MONITOR_SCOPE, max_generation=state["generation"]
                        )
                    )
                self._diagnosis_generation = state["generation"]
            if (
                partial_report is not None
                and eligibility != "blocked"
                and matches_partial_coverage_scan(queue, MONITOR_SCOPE, state, partial_report)
            ):
                self._detail_scan_id = self._latest_scan_id
            result = latest["result"] if latest else {}
            detail_status = self._read_details(queue, count)
            if check_resume:
                self._resumable_scan_id = None
                if eligibility != "blocked" and detail_status["detail_pending_count"]:
                    self._resumable_scan_id = monitor_detail_scan_id(self.database, queue, state)
                detail_status["resume_detail_pending"] = self._resumable_scan_id is not None
            if self._last_detail_finished is not None and due is not None:
                due = max(
                    due,
                    next_poll_at(
                        self._last_detail_finished, interval_seconds=self._state["interval_seconds"]
                    ),
                )
            self._set(
                **detail_status,
                candidate_count=count,
                baseline_initialized=state["baseline"] is not None,
                last_scan_at=_stamp(self._last_finished) if finished is not None else None,
                gap_reason=(
                    result.get("gap_reason")
                    if result.get("gap_reason") in _GAP_REASONS
                    else "scan_requires_review"
                    if result.get("gap_reason") is not None
                    else None
                ),
            )
            return eligibility, due

    def _review(self, reason, *, error_type=None):
        self._set(
            phase="needs_review",
            reason=reason,
            error_type=_safe_error_type(error_type),
            next_eligible_at=None,
        )

    def _after_cycle(self, report):
        if not isinstance(report, dict):
            raise QueueError("The monitor cycle did not return a report")
        status = report.get("status")
        if not isinstance(status, str) or status not in _REPORT_STATUSES:
            raise QueueError("The monitor cycle status is invalid")
        persisted = report.get("cycles_completed", 0)
        added = report.get("new_candidates", 0)
        if (
            type(persisted) is not int
            or not 0 <= persisted <= 1
            or type(added) is not int
            or not 0 <= added <= 1000
            or (persisted == 0 and added != 0)
        ):
            raise QueueError("The monitor cycle has invalid discovery counts")
        closed = report.get("browser_closed")
        with self._lock:
            self._state.update(
                last_scan_status=status, browser_closed=closed, current_cycle_new=added
            )
            self._state["new_candidates"] += added
        self._detail_scan_id = None
        eligibility, _ = self._read_source(
            partial_report=report if status == "watch_test_partial" else None
        )
        if eligibility == "blocked":
            self._review("access_block_requires_review", error_type=report.get("error_type"))
            return False
        if closed is not True:
            self._review("owned_browser_cleanup_unconfirmed", error_type=report.get("error_type"))
            return False
        if status == "watch_busy":
            self._extra_due = self._clock.now() + timedelta(seconds=BUSY_BACKOFF_SECONDS)
            self._set(reason="another_worker_active")
            return True
        due_value = report.get("next_eligible_at_local")
        if due_value is not None:
            self._extra_due = _stored_time(due_value)
        http_status = None
        cycles = report.get("cycles") or []
        if cycles:
            http_status = cycles[-1].get("http_status")
        if status == "watch_test_completed":
            if persisted != 1:
                raise QueueError("The completed monitor cycle has invalid counts")
            if self._extra_due is None and self._last_finished is None:
                raise QueueError("The completed monitor cycle has no durable next time")
            with self._lock:
                self._state["completed_cycles"] += 1
                self._state["reason"] = None
            return True
        if self._detail_scan_id is not None:
            with self._lock:
                self._state["partial_cycles"] += 1
                self._state["reason"] = None
            return True
        if status == "watch_waiting" or http_status in {429, 503}:
            if self._extra_due is None:
                raise QueueError("The waiting monitor cycle has no next time")
            self._set(reason="service_wait" if http_status in {429, 503} else "persisted_cooldown")
            return True
        if status == "watch_test_cancelled" and self._requested_stop():
            return True
        reason = report.get("reason")
        allowed_reasons = {
            "access_block_requires_review",
            "list_profile_unverified_or_incomplete",
            "list_transport_or_inspection_failure",
            "watch_trial_stopped",
            "owned_browser_not_closed",
        }
        self._review(
            reason if reason in allowed_reasons else "scan_requires_review",
            error_type=report.get("error_type"),
        )
        return False

    def _after_detail(self, report):
        if not isinstance(report, dict) or report.get("status") not in _DETAIL_STATUSES:
            raise QueueError("The detail inspection did not return a valid report")
        status = report["status"]
        processed = report.get("candidates_completed", 0)
        if type(processed) is not int or not 0 <= processed <= 1:
            raise QueueError("The detail inspection has invalid counts")
        self._set(browser_closed=report.get("browser_closed"))
        eligibility, _ = self._read_source()
        summaries = report.get("details") or []
        if not isinstance(summaries, list) or len(summaries) > 1:
            raise QueueError("The detail inspection has invalid summaries")
        if (processed == 1 and (len(summaries) != 1 or not isinstance(summaries[0], dict))) or (
            processed == 0 and summaries
        ):
            raise QueueError("The detail inspection summaries do not match its counts")
        if (
            eligibility == "blocked"
            or report.get("reason") == "access_block_requires_review"
            or any(
                isinstance(row, dict) and row.get("http_status") in {401, 403} for row in summaries
            )
        ):
            self._review("access_block_requires_review", error_type=report.get("error_type"))
            return False, processed
        if report.get("browser_closed") is not True:
            self._review("owned_browser_cleanup_unconfirmed", error_type=report.get("error_type"))
            return False, processed
        if status == "candidate_busy":
            self._extra_due = self._clock.now() + timedelta(seconds=BUSY_BACKOFF_SECONDS)
            self._set(reason="another_worker_active", next_eligible_at=_stamp(self._extra_due))
            return True, processed
        due = report.get("next_eligible_at_local")
        if due is not None:
            self._extra_due = _stored_time(due)
            self._set(next_eligible_at=_stamp(self._extra_due))
        if processed:
            summary = summaries[0]
            http_status = summary.get("http_status")
            if http_status in {429, 503}:
                if due is None:
                    raise QueueError("The deferred detail inspection has no next time")
                self._set(reason="service_retry_after")
                return False, processed
            if http_status not in {404, 410} and not (
                summary.get("status") == "observed"
                and type(http_status) is int
                and 200 <= http_status < 400
                and summary.get("time_status") in {"before_baseline", "at_or_after_baseline"}
            ):
                self._review("detail_requires_review", error_type=report.get("error_type"))
                return False, processed
        if status == "candidate_no_pending":
            self._set(reason="no_unattempted_candidates")
            return False, processed
        if status == "candidate_no_baseline":
            self._review("existing_baseline_required")
            return False, processed
        if status == "candidate_waiting":
            if due is None:
                raise QueueError("The waiting detail inspection has no next time")
            self._set(reason="persisted_cooldown")
            return True, processed
        if status == "candidate_test_completed":
            if processed != 1 or due is None:
                raise QueueError("The completed detail inspection has invalid evidence")
            self._set(reason=None)
            return True, processed
        if status == "candidate_test_cancelled" and self._requested_stop():
            return True, processed
        self._review("detail_requires_review", error_type=report.get("error_type"))
        return False, processed

    def _inspect_one(self, *, automatic):
        completed_before = self._state["detail_completed_count"]
        self._set(phase="inspecting", reason=None, browser_closed=None)
        report = self._run_details(
            self.work_root,
            "chrome",
            scope=MONITOR_SCOPE,
            max_candidates=1,
            interval_seconds=self._state["interval_seconds"],
            should_stop=self._requested_stop,
            clock=self._clock,
            **(
                {"expected_scan_id": self._detail_scan_id}
                if automatic and self._detail_scan_id is not None
                else {}
            ),
        )
        keep_batch, count = self._after_detail(report)
        if automatic and keep_batch and report["status"] == "candidate_test_completed":
            if self._state["detail_completed_count"] <= completed_before:
                raise QueueError("The completed automatic inspection has no durable result")
            with self._lock:
                self._state["auto_details_checked"] = min(
                    2**31 - 1, self._state["auto_details_checked"] + 1
                )
        return keep_batch, count, report["status"]

    def _work(self, *, details_only=False):
        task = "details" if details_only else "list"
        select_slot = not details_only
        restored = False
        processed = 0
        try:
            while not self._stop.is_set():
                if self._pause.is_set():
                    self._set(task_kind=task, phase="paused")
                    self._wait(60)
                    continue
                eligibility, due = self._read_source(check_resume=select_slot)
                if select_slot:
                    source = self._resumable_scan_id
                    if task == "list":
                        restored = source is not None
                    elif source != self._detail_scan_id:
                        source = None
                        restored = False
                    self._detail_scan_id = source
                    task = "auto_details" if source is not None else "list"
                    self._set(resume_detail_pending=restored)
                    select_slot = False
                if eligibility == "blocked":
                    self._review("access_block_requires_review")
                    break
                if task == "auto_details":
                    gap = self._state["gap_reason"]
                    if self._detail_scan_id is None:
                        gap_changed = gap is not None
                    else:
                        gap_changed = self._detail_scan_id != self._latest_scan_id or (
                            gap is not None and gap not in PARTIAL_COVERAGE_GAPS
                        )
                    if gap_changed:
                        self._review("scan_requires_review")
                        break
                if task != "list":
                    if not self._state["baseline_initialized"]:
                        self._review("existing_baseline_required")
                        break
                    if self._state["detail_pending_count"] == 0:
                        if details_only:
                            self._set(reason="no_unattempted_candidates")
                            break
                        task = "list"
                        restored = False
                        self._detail_scan_id = None
                        self._set(resume_detail_pending=False)
                if self._extra_due is not None:
                    due = max(due, self._extra_due)
                self._set(task_kind=task, next_eligible_at=_stamp(due))
                remaining = (due - self._clock.now()).total_seconds()
                if remaining > 0:
                    self._set(phase="waiting")
                    self._wait(remaining)
                    continue
                if self._requested_stop():
                    continue
                if shutil.disk_usage(self.work_root).free < MIN_FREE_BYTES:
                    self._review("insufficient_free_space")
                    break
                if task != "list":
                    keep_batch, count, detail_status = self._inspect_one(automatic=not details_only)
                    if self._state["phase"] == "needs_review":
                        break
                    if details_only:
                        processed += count
                        if not keep_batch or processed == MAX_DETAIL_BATCH:
                            break
                    elif (
                        keep_batch
                        and not count
                        and (
                            self._pause.is_set()
                            or self._detail_scan_id is not None
                            and detail_status in {"candidate_busy", "candidate_waiting"}
                        )
                    ):
                        # No navigation consumed the bound turn. A different worker may inspect
                        # a post before the pause, updated service deadline or busy backoff ends.
                        self._detail_scan_id = self._detail_scan_id or self._latest_scan_id
                        select_slot = True
                    else:
                        if restored:
                            self._set(resumed_detail_slot=bool(keep_batch and count))
                            restored = False
                        self._set(resume_detail_pending=False)
                        # Give the next eligible service slot back to discovery,
                        # even if more candidates remain or a server wait applied.
                        task = "list"
                    continue
                self._set(phase="scanning", reason=None, browser_closed=None)
                report = self._run_cycle(
                    self.work_root,
                    "chrome",
                    scope=MONITOR_SCOPE,
                    cycles=1,
                    interval_seconds=self._state["interval_seconds"],
                    should_stop=self._requested_stop,
                    clock=self._clock,
                )
                if not self._after_cycle(report):
                    break
                if self._state["detail_pending_count"] and (
                    report["status"] == "watch_test_completed" or self._detail_scan_id is not None
                ):
                    task = "auto_details"
        except BaseException as error:
            reason = "monitor_stopped_for_review" if task == "list" else "detail_stopped_for_review"
            self._review(reason, error_type=type(error).__name__)
        finally:
            if self._state["phase"] != "needs_review":
                try:
                    self._read_source(check_resume=True)
                except Exception as error:
                    self._review("stored_monitor_data_invalid", error_type=type(error).__name__)
            with self._lock:
                if self._state["phase"] != "needs_review":
                    self._state["phase"] = "stopped"
                else:
                    self._state["resume_detail_pending"] = False
